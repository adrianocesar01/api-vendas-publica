module.exports = class User{

    constructor(codigo, nome, usuario, email, senha){ 

        if(codigo) 
            this.codigo = codigo, 
            this.nome = nome, 
            this.usuario = usuario, 
            this.email = email, 
            this.senha = senha        
    }

    getCodigo(){
        return this.codigo
    }

    setCodigo(codigo){
        this.codigo = codigo
    }

    getNome(){
        return this.codigo
    }

    setNome(nome){
        this.nome = nome
    }
    
    getUsuario(){
        return this.usuario
    }

    setUsuario(usuario){
        this.usuario = usuario
    }

    getEmail(){
        return this.email
    }
    
    setEmail(email){
        this.email = email
    }

    getSenha(){
        return this.senha
    }

    setSenha(senha){
        this.senha = senha
    }
}