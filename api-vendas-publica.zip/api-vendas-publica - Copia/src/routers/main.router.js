const express =  require('express')
const routers = express.Router()

const produtosRouter = require('./produtos.router')
const categoriasRouter = require('./categorias.router')
const fornecedoresRouter = require('./fornecedores.router')
const usersRouter = require('./users.router')

routers.use('/produtos', produtosRouter)
routers.use('/categorias', categoriasRouter)
routers.use('/fornecedores', fornecedoresRouter)
routers.use('/users', usersRouter)

module.exports = routers