const  express = require('express')
const routers = express.Router()

const {uuid} = require('uuidv4')

const {celebrate, Joi} = require('celebrate')

const  database = require('../database/connection')
const Categoria = require('../model/categoria')

routers.post('/',  celebrate({ 

    body : Joi.object().keys({
        nome : Joi.string().min(3).max(30).required() 

    })
    
    }) , async function(request, response){

try{        
   // const { nome } = request.body
   // const categoria = {
     //   codigo: uuid() ,
     //   nome      
   // }
   // await database('categorias').insert(categoria)
   // response.status(201).json(categoria)

    const novaCategoria = new Categoria(uuid(), request.body.nome)

    await database('categorias').insert(novaCategoria)
    response.status(201).json(novaCategoria)
}
    catch(error){
        response.status(400).json({Error: `${error}`})
    }
})


routers.get('/', async function (request, response) {

    try{

    const categorias = await database('categorias').select('*')
    response.status(200).json(categorias)
    }
    catch(error){response.status(400).json({Error: `${error}`})}

})


routers.get('/:codigo', async function (request, response) {

    try{

    const {codigo} = request.params    
    const categoria = await database('categorias').where('codigo', codigo).first()

    if(!categoria) {
        return response.status(400).json(
            {Error: `Codigo ${ codigo } não encontrado.` })
    }

    response.status(200).json(categoria)
}
    catch(error){ 
    response.status(200).json({Error: `${error}` })
    }
})


routers.delete('/:codigo', async function (request, response) {

    const {codigo} = request.params    
    const categoria = await database('categorias').where('codigo', codigo).first()

    if(!categoria) {
        return response.status(400).json(
            {error: 'Codigo ' + codigo + ' não encontrado' })
    }

    await database('categorias').where('codigo', codigo).delete()

    response.status(204).json(categorias)

})

routers.put('/:codigo' ,  celebrate({ 

    body : Joi.object().keys({
        nome : Joi.string().min(3).max(30).required() 

    })
    
    }) , async function (request, response) {

    const {codigo} = request.params    
    const categoria = await database('categorias').where('codigo', codigo).first()

    if(!categoria) {
        return response.status(400).json(
            {error: 'Codigo' + codigo + 'não encontrado' })
    }

    const { nome } = request.body

    const categoriaAlterada = {

        codigo,
        nome

    }
 
    await database('categorias').update(categoriaAlterada).where('codigo', codigo)

    response.status(200).json({codigo, ... categoriaAlterada })
    

})

module.exports = routers