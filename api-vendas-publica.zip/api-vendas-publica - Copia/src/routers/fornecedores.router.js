const  express = require('express')
const routers = express.Router()

const {uuid} = require('uuidv4')

const {celebrate, Joi} = require('celebrate')

const  database = require('../database/connection')
const Fornecedor = require('../model/fornecedor')

routers.post('/',  celebrate({ 

    body : Joi.object().keys({
        nome : Joi.string().min(3).max(30).required() ,
        email : Joi.string().min(13).max(30).required(), 
        telefone : Joi.string().min(11).max(20).required()

    })
    
    }) , async function(request, response){

    const {nome, email, telefone} = request.body

    const fornecedor = {

        codigo: uuid(), 
        nome, 
        email, 
        telefone
        
    }

    await database('fornecedores').insert(fornecedor)

    response.status(201).json(fornecedor)

})


routers.get('/', async function (request, response) {

    const fornecedores = await database('fornecedores').select('*')
    response.status(200).json(fornecedores)

})


routers.get('/:codigo', async function (request, response) {

    const {codigo} = request.params    
    const fornecedor = await database('fornecedores').where('codigo', codigo).first()

    if(!fornecedor) {
        return response.status(400).json(
            {error: 'Codigo' + codigo + 'não encontrado' })
    }

    response.status(200).json(fornecedor)

})


routers.delete('/:codigo', async function (request, response) {

    const {codigo} = request.params    
    const fornecedor = await database('fornecedores').where('codigo', codigo).first()

    if(!fornecedor) {
        return response.status(400).json(
            {error: 'Codigo' + codigo + 'não encontrado' })
    }

    await database('fornecedores').where('codigo', codigo).delete()

    response.status(204).json()

})

routers.put('/:codigo' ,  celebrate({ 

    body : Joi.object().keys({
        nome : Joi.string().min(3).max(30).required() ,
        email : Joi.string().min(13).max(30).required(), 
        telefone : Joi.string().min(11).max(20).required()

    })
    
    }) , async function (request, response) {

    const {codigo} = request.params    
    const fornecedor = await database('fornecedores').where('codigo', codigo).first()

    if(!fornecedor) {
        return response.status(400).json(
            {error: 'Codigo' + codigo + 'não encontrado' })
    }

    const { nome, email, telefone } = request.body

    const fornecedorAlterado = {

        codigo: uuid(),
        nome,
        email, 
        telefone

    }
 
    await database('fornecedores').update(fornecedorAlterado).where('codigo', codigo)

    response.status(200).json({codigo, ... fornecedorAlterado })
    

})

module.exports = routers