const  express = require('express')
const routers = express.Router()

const {uuid} = require('uuidv4')

const {celebrate, Joi} = require('celebrate')

const  database = require('../database/connection')
const Produto = require('../model/produto')


routers.post('/',  celebrate({ 

    body : Joi.object().keys({ 
        nome : Joi.string().min(3).max(30).required(), 
        codigoCategoria : Joi.string().min(36).max(36).required(), 
        codigoFornecedor : Joi.string().min(36).max(36).required(), 
        valor : Joi.number().min(0).required(), 


    })
    
    }) , async function(request, response){

    try{    

    const { nome, codigoCategoria, codigoFornecedor, valor } = request.body
    
    const produto =  {

        codigo: uuid(), 
        nome, 
        codigoCategoria, 
        codigoFornecedor, 
        valor,
        ativo : 1
    }

    await database('produtos').insert(produto)
    
    response.status(201).json(produto) 
    
}
catch(error){response.status(400).json({Error: `${error}`})
}

})


routers.get('/', async function (request, response) {

try{
    const produtos = await database('produtos')
                    .join('categorias', 
                            'categorias.codigo', '=' , 
                            'produtos.codigoCategoria')
                    .join('fornecedores', 
                            'fornecedores.codigo', '=' , 
                            'produtos.codigoFornecedor')
                    .select('produtos.codigo as codigo do produto', 
                            'produtos.nome as nome do produto', 
                            'produtos.codigoCategoria as codigo da categoria', 
                            'categorias.nome as nome da categoria' ,
                            'produtos.codigoFornecedor as codigo do fornecedor',
                            'fornecedores.nome as nome do fornecedor' , 
                            'produtos.valor as valor do produto',  
                            'produtos.ativo as ativo ou não')
    
    response.status(200).json(produtos) 
}
 catch(error){ 
    response.status(200).json({Error: `${error} ` })
    }
})


routers.get('/:codigo', async function (request, response) {

    const {codigo} = request.params    
    const produto = await database('produtos').where('codigo', codigo).first()

    if(!produto) {
        return response.status(400).json(
            {error: 'Codigo' + codigo + 'não encontrado' })
    }

    response.status(200).json(produto)

})


routers.delete('/:codigo', async function (request, response) {

    const {codigo} = request.params    
    const produto = await database('produtos').where('codigo', codigo).first()

    if(!produto) {
        return response.status(400).json(
            {error: 'Codigo' + codigo + 'não encontrado' })
    }

    await database('produtos').where('codigo', codigo).delete()

    response.status(204).json()

})

routers.put('/:codigo' ,  celebrate({ 

    body : Joi.object().keys({ 
        nome : Joi.string().min(3).max(30).required(), 
        codigoCategoria : Joi.string().min(36).max(36).required(), 
        codigoFornecedor : Joi.string().min(36).max(36).required(), 
        valor : Joi.number().min(0).required(), 

    })
    
    }) , async function (request, response) {

    const {codigo} = request.params    
    const produto = await database('produtos').where('codigo', codigo).first()

    if(!produto) {
        return response.status(400).json(
            {error: 'Codigo' + codigo + 'não encontrado' })
    }

    const { nome, codigoCategoria, codigoFornecedor, valor} = request.body


    const produtoAlterado = { 

        codigo: uuid(), 
        nome, 
        codigoCategoria, 
        codigoFornecedor, 
        valor, 
        ativo : 1
    }
     
 
    await database('produtos').update(produtoAlterado).where('codigo', codigo)

    response.status(200).json({codigo, ... produtoAlterado })
    

})

module.exports = routers