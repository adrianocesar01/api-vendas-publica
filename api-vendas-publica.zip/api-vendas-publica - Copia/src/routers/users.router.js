const  express = require('express')

const routers = express.Router()

const {uuid} = require('uuidv4')

const {celebrate, Joi} = require('celebrate')

//const JoiPassword = require('joi-password') 

//const schema = JoiPassword.object({
 //   senha: JoiPassword.string().pattern(new RegExp('^[a-zA-Z0-9]{3,30}$')),
  //  repeat_password: JoiPassword.ref('password'),
    //access_token: []
//})

const  database = require('../database/connection')

routers.post('/',  celebrate({ 

    body : Joi.object().keys({
        nome : Joi.string().max(40).required() ,
        email : Joi.string().max(60).required() ,
        usuario : Joi.string().max(15).required() ,
        senha : Joi.string().max(15).required() ,
       
 //.token() ---> Requer que o valor da string contenha apenas a-z, A-Z, 0-9 e sublinhado _.

 //.lowercase() ---> Requer que o valor da string esteja em letras minúsculas

 //.uppercase() ---> Requer que o valor da string esteja em letras maiúsculas
    })
    
    }) , async function(request, response){

    const { nome, email, usuario, senha} = request.body

    const user = {

        codigo: uuid(), 
        nome, 
        email, 
        usuario, 
        senha, 
        ativo : 1
        
    }

    await database('users').insert(user)

    response.status(201).json(user)

})


routers.get('/', async function (request, response) {

    const users = await database('users').select('*')
    response.status(200).json(users)

})


routers.get('/:codigo', async function (request, response) {

    const {codigo} = request.params    
    const user = await database('users').where('codigo', codigo).first()

    if(!user) {
        return response.status(400).json(
            {error: 'Codigo' + codigo + 'não encontrado' })
    }

    response.status(200).json(user)

})


routers.put('/:codigo' ,  celebrate({ 

    body : Joi.object().keys({
        nome : Joi.string().max(40).required(), 
        email : Joi.string().max(60).required(), 
        senha : Joi.string().max(15).required() 

    })
    
    }) , async function (request, response) {

    const {codigo} = request.params    
    const user = await database('users').where('codigo', codigo).first()

    if(!user) {
        return response.status(400).json(
            {error: 'Codigo' + codigo + 'não encontrado' })
    }

    const { nome, email, senha } = request.body

    const userAlterated= {

        codigo: uuid() ,
        nome, 
        email, 
        senha,
        ativo : 1

    }
 
    await database('users').update(userAlterated).where('codigo', codigo)

    response.status(200).json({codigo, ... userAlterated })
    

})

module.exports = routers